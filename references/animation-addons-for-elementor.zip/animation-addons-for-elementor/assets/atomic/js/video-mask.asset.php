<?php return array('dependencies' => array(), 'version' => 'c3fa756ed01f49b3d583');
