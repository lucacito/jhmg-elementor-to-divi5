<?php return array('dependencies' => array(), 'version' => '6fcb4352b15f64bd2380');
