<?php return array('dependencies' => array(), 'version' => '2b7672e96b3948f90271');
