<?php return array('dependencies' => array(), 'version' => '32d1ca99d439dac68f3e');
