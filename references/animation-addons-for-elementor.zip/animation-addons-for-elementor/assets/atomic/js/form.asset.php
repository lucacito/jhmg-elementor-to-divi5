<?php return array('dependencies' => array(), 'version' => 'd8c05c5aed018c822c5b');
