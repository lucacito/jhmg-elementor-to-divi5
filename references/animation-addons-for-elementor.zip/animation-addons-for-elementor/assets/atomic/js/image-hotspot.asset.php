<?php return array('dependencies' => array(), 'version' => 'c505f9569d49e6432f32');
