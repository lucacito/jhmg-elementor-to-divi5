<?php return array('dependencies' => array(), 'version' => '5aa3b3d2acd32c7a5f0d');
