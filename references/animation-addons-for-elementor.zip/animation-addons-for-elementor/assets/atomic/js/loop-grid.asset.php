<?php return array('dependencies' => array(), 'version' => '3b21c17992742b1217c9');
