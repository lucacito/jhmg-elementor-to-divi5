<?php return array('dependencies' => array(), 'version' => '57cf92d34720a45d69f6');
