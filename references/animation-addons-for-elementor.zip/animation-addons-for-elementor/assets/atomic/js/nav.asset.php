<?php return array('dependencies' => array(), 'version' => 'd78e418d924542c19648');
