<?php return array('dependencies' => array(), 'version' => '18ef58bd87f04017909c');
