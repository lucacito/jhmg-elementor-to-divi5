<?php return array('dependencies' => array(), 'version' => '55e05fab32e826c5da7d');
