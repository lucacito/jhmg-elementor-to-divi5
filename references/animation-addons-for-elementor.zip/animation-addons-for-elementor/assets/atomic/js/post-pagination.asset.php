<?php return array('dependencies' => array(), 'version' => '6b9d00ebc438a9f816e3');
