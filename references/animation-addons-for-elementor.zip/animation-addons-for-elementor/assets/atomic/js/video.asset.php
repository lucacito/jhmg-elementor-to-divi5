<?php return array('dependencies' => array(), 'version' => '17a3b5a64069b873423d');
