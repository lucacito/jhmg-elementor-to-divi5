<?php return array('dependencies' => array(), 'version' => '0bb343f89fbe3192bf8d');
