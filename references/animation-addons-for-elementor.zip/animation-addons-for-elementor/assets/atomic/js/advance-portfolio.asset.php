<?php return array('dependencies' => array(), 'version' => 'bc7e893e324939f53dd5');
