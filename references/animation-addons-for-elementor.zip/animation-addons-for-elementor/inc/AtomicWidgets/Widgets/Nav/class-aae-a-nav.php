<?php
namespace Wealcoder\AnimationAddons\AtomicWidgets\Widgets\Nav;

use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Svg_Control;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Html_V3_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Svg_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;

require_once __DIR__ . '/class-aae-a-nav-item.php';
require_once __DIR__ . '/class-aae-a-nav-sub-item.php';
require_once __DIR__ . '/class-aae-a-nav-items-control.php';
require_once __DIR__ . '/class-aae-a-mobile-nav.php';
require_once __DIR__ . '/class-aae-a-mobile-nav-lifecycle-control.php';

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Per-breakpoint colour/size for the dropdown indicator. Not PSR-4 (this folder is
// loaded by class-atomic.php's registry, not the autoloader), so it has to be
// required explicitly. Registering here rather than in class-atomic.php keeps
// the element self-contained; register() is idempotent.
require_once __DIR__ . '/class-aae-a-nav-responsive.php';
Aaeaddon_A_Nav_Responsive::register();

class Aaeaddon_A_Nav extends Atomic_Element_Base {
	use Has_Element_Template;

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->meta( 'is_container', true );
	}

	public static function get_type() {
		return 'e-aae-a-nav';
	}

	public static function get_element_type(): string {
		return 'e-aae-a-nav';
	}

	public function get_title() {
		return esc_html__( 'Nav', 'animation-addons-for-elementor' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_keywords() {
		return [ 'nav', 'menu', 'navbar', 'navigation', 'atomic', 'aae' ];
	}

	public function get_categories(): array {
		return ['aae-atomic-general','wcf-hf-addon'];
	}

	/**
	 * Panel category for the Elements panel.
	 *
	 * Atomic_Element_Base reads the panel category from HERE — get_categories()
	 * is Widget_Base's hook and is never called for an element type, so a
	 * category declared only there silently falls back to Elementor's own
	 * 'v4-elements' ("Atomic Elements") bucket. Delegate so both stay in sync.
	 */
	protected function define_panel_categories(): array {
		return $this->get_categories();
	}

	protected static function define_props_schema(): array {
		// The `aae_ndi_` icon-style props are MERGED IN, never a replacement:
		// every prop below keeps its key, its type and its stored value, so an
		// existing nav renders untouched. See class-aae-a-nav-responsive.php.
		return Aaeaddon_A_Nav_Responsive::props_schema() + [
			'classes'    => Classes_Prop_Type::make()->default( [] ),
			'attributes' => Attributes_Prop_Type::make()->meta( Overridable_Prop_Type::ignore() ),
			/* Set when the menu was populated via "Import from WordPress menu".
			 * Binds this nav to that WP menu so the panel offers "Update from
			 * WordPress" (id-based smart sync) instead of a duplicate import. */
			'imported_menu_id' => String_Prop_Type::make()->default( '' ),
			/* Re-sync this nav from its linked WP menu on every editor open, so
			 * "Update from WordPress" is only needed for a deliberate reset.
			 * Structure only — auto-sync adds and removes items but never
			 * overwrites a label or link edited here (see syncMenuLevel's
			 * structureOnly path in NavItemsControl.jsx).
			 * Defaults to FALSE and is switched on at import time instead: a page
			 * imported before this existed must not change behaviour by itself
			 * the next time someone opens it. */
			'menu_autosync' => Boolean_Prop_Type::make()->default( false ),
			/* Desktop dropdown indicator icon. nav.js inlines this SVG next to the
			 * label of every item that has a dropdown (see injectDropdownIcons). */
			'show_dropdown_icon' => Boolean_Prop_Type::make()->default( true ),
			'dropdown_icon' => Svg_Src_Prop_Type::make()
				->default_url( AAEADDON_URL . 'inc/AtomicWidgets/Widgets/Nav/assets/icons/chevron-down.svg' ),
			'mobile_enabled' => Boolean_Prop_Type::make()->default( false ),
			'mobile_breakpoint' => String_Prop_Type::make()->default( '767' ),
			'mobile_position' => String_Prop_Type::make()->default( 'right' ),
			'mobile_close_on_link' => Boolean_Prop_Type::make()->default( true ),
			'mobile_lock_scroll' => Boolean_Prop_Type::make()->default( true ),
			/* EDITOR-ONLY drawer preview switch.
			 *
			 * The editor used to open the mobile drawer by itself as soon as the
			 * device switcher dropped to or below `mobile_breakpoint`. That was
			 * surprising — previewing tablet popped the menu open over the canvas —
			 * and the device-mode probe behind it (getEditorDeviceMode) is exactly
			 * where the intermittent "drawer stuck open, X does nothing" reports came
			 * from: when the probe answered stale, the preview reopened itself faster
			 * than the close button could dismiss it.
			 *
			 * The breakpoint is now purely a FRONTEND concern (nav.js matchMedia
			 * against the real viewport); in the editor the builder opens the drawer
			 * from this switch when they want to fill or style it.
			 *
			 * Defaults to false, so opening a page saved before this existed shows a
			 * closed drawer, and it has NO effect on the frontend at all. */
			'mobile_editor_open' => Boolean_Prop_Type::make()->default( false ),
			/* Icon pickers mirrored to the companion's SVG children by the
			 * NavItemsControl reconciler. Default to the bundled icons so the
			 * control shows the current icon and swapping is one click. */
			'mobile_hamburger_icon' => Svg_Src_Prop_Type::make()
				->default_url( AAEADDON_URL . 'inc/AtomicWidgets/Widgets/Nav/assets/icons/hamburger.svg' ),
			'mobile_close_icon' => Svg_Src_Prop_Type::make()
				->default_url( AAEADDON_URL . 'inc/AtomicWidgets/Widgets/Nav/assets/icons/close.svg' ),
			'mobile_dropdown_icon' => Svg_Src_Prop_Type::make()
				->default_url( AAEADDON_URL . 'inc/AtomicWidgets/Widgets/Nav/assets/icons/chevron-down.svg' ),
			'mobile_back_icon' => Svg_Src_Prop_Type::make()
				->default_url( AAEADDON_URL . 'inc/AtomicWidgets/Widgets/Nav/assets/icons/chevron-left.svg' ),
		];
	}

	/**
	 * Breakpoint choices, built from the SITE'S OWN active breakpoints.
	 *
	 * This used to be a hardcoded 767 / 1024 pair. Elementor's breakpoints are
	 * user-configurable — 767 and 1024 are only the DEFAULTS
	 * (`elementor/core/breakpoints/manager.php`) — so on a site that customised
	 * them, the Nav switched to mobile at a width nothing else on the page
	 * agreed with. Reading the real values is what makes the menu flip at the
	 * same point as the rest of the site's responsive design.
	 *
	 * The stored value stays the PIXEL NUMBER as a string, exactly as before, so
	 * every saved page keeps working untouched. (`mobile_breakpoint` has no
	 * ->enum(), so no schema change is involved either.)
	 *
	 * 767 and 1024 are ALWAYS offered even when the site no longer uses them: an
	 * atomic Select whose stored value is absent from its options renders blank
	 * and can lose the value on the next save. A slightly longer list is a fair
	 * price for never silently resetting a live page's breakpoint.
	 *
	 * Guard pattern copied from inc/Atomic/Traits/Responsive_Config.php:166.
	 *
	 * @return array<int, array{value: string, label: string}>
	 */
	private static function breakpoint_options(): array {
		$by_px = [];

		if ( class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->breakpoints )
			&& method_exists( \Elementor\Plugin::$instance->breakpoints, 'get_active_breakpoints' ) ) {

			foreach ( \Elementor\Plugin::$instance->breakpoints->get_active_breakpoints() as $key => $breakpoint ) {
				if ( ! is_object( $breakpoint ) || ! method_exists( $breakpoint, 'get_value' ) ) {
					continue;
				}

				$px = (int) $breakpoint->get_value();

				if ( $px <= 0 ) {
					continue;
				}

				$name = ucwords( str_replace( '_', ' ', (string) $key ) );

				$by_px[ $px ] = [
					'value' => (string) $px,
					/* translators: 1: breakpoint name, 2: width in pixels. */
					'label' => sprintf( __( '%1$s (%2$dpx)', 'animation-addons-for-elementor' ), $name, $px ),
				];
			}
		}

		// Legacy fallbacks — also the whole list when Elementor's manager is absent.
		$legacy = [
			767  => __( 'Mobile', 'animation-addons-for-elementor' ),
			1024 => __( 'Tablet', 'animation-addons-for-elementor' ),
		];

		foreach ( $legacy as $px => $name ) {
			if ( ! isset( $by_px[ $px ] ) ) {
				$by_px[ $px ] = [
					'value' => (string) $px,
					/* translators: 1: breakpoint name, 2: width in pixels. */
					'label' => sprintf( __( '%1$s (%2$dpx)', 'animation-addons-for-elementor' ), $name, $px ),
				];
			}
		}

		ksort( $by_px );

		return array_values( $by_px );
	}

	protected function define_atomic_controls(): array {
		return [
			Section::make()
				->set_label( __( 'Mobile Menu', 'animation-addons-for-elementor' ) )
				->set_id( 'mobile_menu' )
				->set_items( [
					Switch_Control::bind_to( 'mobile_enabled' )
						->set_label( __( 'Enable Mobile Menu', 'animation-addons-for-elementor' ) ),
					/* Editor-only helper, kept next to Enable Mobile Menu because that is
					 * the pair a builder reaches for: switch the mobile menu on, then
					 * open it to style the drawer. Same placement rationale as the
					 * Offcanvas widget's "Open Panel (Editor)". No frontend effect. */
					Switch_Control::bind_to( 'mobile_editor_open' )
						->set_label( __( 'Open Mobile Menu (Editor)', 'animation-addons-for-elementor' ) ),
					Select_Control::bind_to( 'mobile_breakpoint' )
						->set_label( __( 'Breakpoint', 'animation-addons-for-elementor' ) )
						->set_options( self::breakpoint_options() ),
					Select_Control::bind_to( 'mobile_position' )
						->set_label( __( 'Drawer Position', 'animation-addons-for-elementor' ) )
						->set_options( [
							[ 'value' => 'right', 'label' => __( 'Right', 'animation-addons-for-elementor' ) ],
							[ 'value' => 'left', 'label' => __( 'Left', 'animation-addons-for-elementor' ) ],
						] ),
					Switch_Control::bind_to( 'mobile_close_on_link' )
						->set_label( __( 'Close on Link Click', 'animation-addons-for-elementor' ) ),
					Switch_Control::bind_to( 'mobile_lock_scroll' )
						->set_label( __( 'Lock Body Scroll', 'animation-addons-for-elementor' ) ),
					Svg_Control::bind_to( 'mobile_hamburger_icon' )
						->set_label( __( 'Hamburger Icon', 'animation-addons-for-elementor' ) ),
					Svg_Control::bind_to( 'mobile_close_icon' )
						->set_label( __( 'Close Icon', 'animation-addons-for-elementor' ) ),
					Svg_Control::bind_to( 'mobile_dropdown_icon' )
						->set_label( __( 'Dropdown Icon', 'animation-addons-for-elementor' ) ),
					Svg_Control::bind_to( 'mobile_back_icon' )
						->set_label( __( 'Back Icon', 'animation-addons-for-elementor' ) ),
					Aaeaddon_A_Mobile_Nav_Lifecycle_Control::make()
						->set_label( '' )
						->set_meta( [ 'layout' => 'custom' ] ),
				] ),

			Section::make()
				->set_label( __( 'Dropdown Icon', 'animation-addons-for-elementor' ) )
				->set_id( 'dropdown_icon_section' )
				->set_items( [
					Switch_Control::bind_to( 'show_dropdown_icon' )
						->set_label( __( 'Show Icon on Dropdown Items', 'animation-addons-for-elementor' ) ),
					Svg_Control::bind_to( 'dropdown_icon' )
						->set_label( __( 'Icon', 'animation-addons-for-elementor' ) ),
					Text_Control::bind_to( Aaeaddon_A_Nav_Responsive::anchor( 'dropdown_icon' ) ),
				] ),
			Section::make()
				->set_label( __( 'Menu Items', 'animation-addons-for-elementor' ) )
				->set_id( 'menu_items' )
				->set_items( [
					Switch_Control::bind_to( 'menu_autosync' )
						->set_label( __( 'Auto-sync from WordPress', 'animation-addons-for-elementor' ) ),
					Aaeaddon_A_Nav_Items_Control::make()
						->set_label( __( 'Items', 'animation-addons-for-elementor' ) )
						->set_meta( [ 'layout' => 'custom' ] ),
				] ),
			Section::make()
				->set_label( __( 'Settings', 'animation-addons-for-elementor' ) )
				->set_id( 'settings' )
				->set_items( [
					Text_Control::bind_to( '_cssid' )
						->set_label( __( 'ID', 'animation-addons-for-elementor' ) )
						->set_meta( $this->get_css_id_control_meta() ),
				] ),
		];
	}

	/**
	 * Bare-drop structural CSS moved out of the external nav.scss into the
	 * element's own base style (atomic optimization: each element ships the CSS
	 * it needs). `position: relative` gives the menu a positioning context;
	 * `overflow: visible` lets future dropdowns escape. Emitted WITHOUT
	 * `!important` (base styles never do) so the user's Style tab always wins —
	 * safe here because nothing else sets position/overflow on this element.
	 * The bare 'base' key also feeds the Twig root its scope class.
	 * NOTE: `min-height: unset` stays in nav.scss — `unset` is not expressible
	 * as an atomic Size prop.
	 */
	protected function define_base_styles(): array {
		return [
			'base' => Style_Definition::make()
				->add_variant(
					Style_Variant::make()
						->add_prop( 'position', String_Prop_Type::generate( 'relative' ) )
						->add_prop( 'overflow', String_Prop_Type::generate( 'visible' ) )
				),
		];
	}

	protected function define_default_children() {
		$make_item = function ( $title, $has_dropdown = false, array $children = [] ) {
			$builder = Aaeaddon_A_Nav_Item::generate()
				->editor_settings( [ 'title' => $title ] )
				->settings( [
					'text' => Html_V3_Prop_Type::generate( [
						'content'  => String_Prop_Type::generate( $title ),
						'children' => [],
					] ),
					'has_dropdown' => Boolean_Prop_Type::generate( $has_dropdown ),
				] );
			if ( $children ) {
				$builder->children( $children );
			}
			return $builder->build();
		};

		return [
			$make_item( 'Menu Item 1' ),
			$make_item( 'Menu Item 2' ),
			$make_item( 'Menu Item 3' ),
			$make_item( 'Menu Item 4' ),
		];
	}

	protected function define_allowed_child_types() {
		return [ 'e-aae-a-nav-item' ];
	}

	protected function define_default_html_tag() {
		/* <div> (not <ul>): items render as <div> too, so no <ul>/<li> parser
		 * mangling of nested menus. See aae-a-nav.html.twig. */
		return 'div';
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/aae-a-nav' => __DIR__ . '/aae-a-nav.html.twig',
		];
	}

	public function get_script_depends(): array {
		return [ 'aae-a-nav-js' ];
	}

	public function get_style_depends(): array {
		return [ 'aae-a-nav-css' ];
	}
}
