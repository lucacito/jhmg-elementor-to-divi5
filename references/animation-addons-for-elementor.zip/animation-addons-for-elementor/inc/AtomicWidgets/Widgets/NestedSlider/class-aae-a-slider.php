<?php
namespace Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider;

use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Element_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Element_Template;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Indicators;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Controls\Section;

use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;

use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slide;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slides_Control;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Track;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Nav_Prev;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Nav_Next;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Pagination;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Current;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Total;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Percentage;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Progress;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Progress_Fill;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Divider;
use Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider\Aaeaddon_A_Slider_Counter;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Aaeaddon_A_Slider extends Atomic_Element_Base {
	use Has_Element_Template;

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->meta( 'is_container', true );
	}

	public static function get_type() {
		return 'e-aae-a-slider';
	}

	public static function get_element_type(): string {
		return 'e-aae-a-slider';
	}

	public function get_title() {
		return esc_html__( 'Nested Slider', 'animation-addons-for-elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_keywords() {
		return [ 'slider', 'nested', 'atomic', 'gsap' ];
	}

	public function get_categories(): array {
		return ['aae-atomic-general'];
	}

	/**
	 * Panel category for the Elements panel.
	 *
	 * Atomic_Element_Base reads the panel category from HERE — get_categories()
	 * is Widget_Base's hook and is never called for an element type, so a
	 * category declared only there silently falls back to Elementor's own
	 * 'v4-elements' ("Atomic Elements") bucket. Delegate so both stay in sync.
	 */
	protected function define_panel_categories(): array {
		return $this->get_categories();
	}

	protected static function define_props_schema(): array {
		return [
			// Snapshot of this element's own full model (JSON), captured by the
			// JS preset-apply engine the first time a preset is applied — see
			// preset-apply.js's SNAPSHOT_REVERT_TYPES / "Reset to Default".
			'aae_preset_snapshot' => String_Prop_Type::make()->default( '' ),

			'classes' => Classes_Prop_Type::make()->default( [] ),
			'attributes' => Attributes_Prop_Type::make()->meta( Overridable_Prop_Type::ignore() ),
		];
	}

    protected function define_atomic_controls(): array {
		require_once __DIR__ . '/class-aae-a-slides-control.php';
		require_once __DIR__ . '/class-aae-a-preset-picker-control.php';

		return [
			Section::make()
				->set_label( __( 'Presets', 'animation-addons-for-elementor' ) )
				->set_id( 'aae_presets' )
				->set_items(
					[
						Aaeaddon_A_Preset_Picker_Control::make()
							->set_label( __( 'Apply Preset', 'animation-addons-for-elementor' ) )
							->set_meta( [ 'layout' => 'custom' ] ),
					]
				),

			Section::make()
				->set_label( __( 'Slides', 'animation-addons-for-elementor' ) )
				->set_id( 'slides' )
				->set_items( [
					Aaeaddon_A_Slides_Control::make()
						->set_label( __( 'Slides', 'animation-addons-for-elementor' ) )
						->set_meta( [ 'layout' => 'custom' ] ),
				] ),
			// "Slider Settings": the anchor control is replaced in the editor by the
			// ResponsiveSection (General/Advanced tabs); the ID field lives in the
			// same section right after it, so there's one combined section instead
			// of a separate "Settings". Built here (not via Controls.php's filter)
			// because the ID control needs the protected get_css_id_control_meta().
			Section::make()
				->set_label( __( 'Slider Settings', 'animation-addons-for-elementor' ) )
				->set_id( 'slider_settings' )
				->set_items( [
					Text_Control::bind_to( \Wealcoder\AnimationAddons\Atomic\NestedSlider\Schema::SLIDER_SECTION_ANCHOR ),
					Text_Control::bind_to( '_cssid' )
						->set_label( __( 'ID', 'animation-addons-for-elementor' ) )
						->set_meta( $this->get_css_id_control_meta() ),
				] ),
		];
	}

	protected function define_base_styles(): array {
		// We apply base flex styles. Notice we don't bind dynamic gap here, we do it in twig variables.
		$wrapper_styles = [
			'display'  => String_Prop_Type::generate( 'block' ),
			'position' => String_Prop_Type::generate( 'relative' ),
			'width'    => Size_Prop_Type::generate( array( 'size' => 100, 'unit' => '%' ) ),
		];

		return [
			'base' => Style_Definition::make()
				->add_variant( Style_Variant::make()->add_props( $wrapper_styles ) )	
		];
	}

	/**
	 * Marker class stamped on every DIRECT child seeded below.
	 *
	 * Read by the editor's auto-preset watcher as its `defaultMarker` — see
	 * AUTO_PRESETS in src/modules/atomic/editor-bridge/auto-preset.js. Same
	 * device the Image Compare widget uses (`aae-ic-default`), and for the same
	 * reason: the watcher decides "is this still an untouched drop?" by looking
	 * at the children, and shape alone is not a safe answer. A preset that
	 * happens to keep all five parts — a perfectly reasonable thing for a user
	 * to export — would look identical to a fresh drop, and the watcher would
	 * re-apply the default preset to its own output forever, since the
	 * replacement element gets a new id and so is never caught by `handled`.
	 *
	 * A preset's children never carry this class, so its absence is a definite
	 * "already presetted". Existing saved sliders don't carry it either, which
	 * is also correct: they must never be restyled.
	 */
	const DEFAULT_CHILD_MARKER = 'aae-slider-default';

	/** The marker as a `classes` prop, for the seeded children below. */
	private static function default_marker_classes() {
		return Classes_Prop_Type::generate( [ self::DEFAULT_CHILD_MARKER ] );
	}

	protected function define_default_children() {
		// Start with 5 empty slides; the user fills each one.
		$slides = [];
		for ( $i = 1; $i <= 1; $i++ ) {
			$slides[] = Aaeaddon_A_Slide::generate()
				->editor_settings( [ 'title' => 'Slide ' . $i ] )
				->build();
		}

		return [
			Aaeaddon_A_Slider_Track::generate()
				->editor_settings( [ 'title' => 'Slider Track' ] )
				->settings( [ 'classes' => self::default_marker_classes() ] )
				->children( $slides )
				->build(),
			Aaeaddon_A_Slider_Nav_Prev::generate()
				->editor_settings( [ 'title' => 'Prev Nav' ] )
				->settings( [ 'classes' => self::default_marker_classes() ] )
				->build(),
			Aaeaddon_A_Slider_Nav_Next::generate()
				->editor_settings( [ 'title' => 'Next Nav' ] )
				->settings( [ 'classes' => self::default_marker_classes() ] )
				->build(),
			Aaeaddon_A_Slider_Pagination::generate()
				->editor_settings( [ 'title' => 'Pagination' ] )
				->settings( [ 'classes' => self::default_marker_classes() ] )
				->build(),
			Aaeaddon_A_Slider_Indicators::generate()
				->editor_settings( [ 'title' => 'Indicators' ] )
				->settings( [ 'classes' => self::default_marker_classes() ] )
				->children( [
					Aaeaddon_A_Slider_Counter::generate()
						->editor_settings( [ 'title' => 'Slide Counter' ] )
						->build(),
					Aaeaddon_A_Slider_Progress::generate()
						->editor_settings( [ 'title' => 'Progress Line' ] )
						->build(),
					Aaeaddon_A_Slider_Percentage::generate()
						->editor_settings( [ 'title' => 'Progress %' ] )
						->build(),
				] )
				->build(),
		];
	}

	protected function define_allowed_child_types() {
		return [
			'e-aae-a-slider-track',
			'e-aae-a-slider-nav-prev',
			'e-aae-a-slider-nav-next',
			'e-aae-a-slider-pagination',
			'e-aae-a-slider-current',
			'e-aae-a-slider-total',
			'e-aae-a-slider-progress',
			'e-aae-a-slider-percentage',
			'e-aae-a-slider-indicators',
			'e-aae-a-slider-counter',
			'e-aae-a-slider-divider',
			'e-aae-a-slider-progress-fill',
			'e-flexbox',
			'e-grid',
			'e-div-block'
		];
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/aae-a-slider' => __DIR__ . '/aae-a-slider.html.twig',
		];
	}

	public function get_style_depends(): array {
		return [ 'aae-a-slider-css' ];
	}	
}
