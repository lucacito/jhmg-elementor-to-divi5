<?php
namespace Wealcoder\AnimationAddons\AtomicWidgets\Widgets\NestedSlider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base' ) ) {
	return;
}

use Elementor\Modules\AtomicWidgets\Elements\Base\Atomic_Widget_Base;
use Elementor\Modules\AtomicWidgets\Elements\Base\Has_Template;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\PropTypes\Classes_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Attributes_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Style_Definition;
use Elementor\Modules\AtomicWidgets\Styles\Style_Variant;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Background_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Color_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\Components\PropTypes\Overridable_Prop_Type;

class Aaeaddon_A_Slider_Progress_Fill extends Atomic_Widget_Base {
	use Has_Template;

	const BASE_STYLE_KEY = 'base';

	public static $widget_description = 'Animated fill bar inside the slider progress track.';
	
	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->meta( 'permanently_locked', true );
	}
	public static function generate() {
		return parent::generate()->is_locked( true );
	}

	// Atomic_Widget_Base reads show_in_panel(), not should_show_in_panel().
	public function show_in_panel() {
		return false;
	}

	public static function get_element_type(): string {
		return 'e-aae-a-slider-progress-fill';
	}

	public function get_title() {
		return esc_html__( 'Progress Fill', 'animation-addons-for-elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	public function get_keywords() {
		return [ 'slider', 'progress', 'fill', 'atomic' ];
	}

	protected static function define_props_schema(): array {
		return [
			'classes'    => Classes_Prop_Type::make()->default( [] ),
			'attributes' => Attributes_Prop_Type::make()->meta( Overridable_Prop_Type::ignore() ),
		];
	}

	protected function define_atomic_controls(): array {
		return [
			Section::make()
				->set_label( __( 'Settings', 'animation-addons-for-elementor' ) )
				->set_id( 'settings' )
				->set_items( [
					Text_Control::bind_to( '_cssid' )
						->set_label( __( 'ID', 'animation-addons-for-elementor' ) )
						->set_meta( $this->get_css_id_control_meta() ),
				] ),
		];
	}

	protected function define_base_styles(): array {
		$styles = [
			'position'            => String_Prop_Type::generate( 'absolute' ),
			'inset-block-start'   => Size_Prop_Type::generate( [ 'size' => 0, 'unit' => 'px' ] ),
			'inset-inline-start'  => Size_Prop_Type::generate( [ 'size' => 0, 'unit' => 'px' ] ),
			'height'              => Size_Prop_Type::generate( [ 'size' => 100, 'unit' => '%' ] ),
			'width'               => Size_Prop_Type::generate( [ 'size' => 100, 'unit' => '%' ] ),
			'background'          => Background_Prop_Type::generate( [
				'color' => Color_Prop_Type::generate( '#7b5cf0' ),
			] ),
		];

		return [
			self::BASE_STYLE_KEY => Style_Definition::make()
				->add_variant( Style_Variant::make()->add_props( $styles ) ),
		];
	}

	protected function get_templates(): array {
		return [
			'elementor/elements/aae-a-slider-progress-fill' => __DIR__ . '/aae-a-slider-progress-fill.html.twig',
		];
	}
}
