<?php
namespace Wealcoder\AnimationAddons\Atomic\Presets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the transient cache for remote presets and merges them with local
 * bundled presets (Local_Fallback) — merge, not fallback-only: if local
 * files exist for a type, they show up in the SAME dropdown as remote
 * presets. Local presets tag `source: 'local'` and get no thumbnail_url
 * (client renders the placeholder for these); remote presets tag
 * `source: 'remote'`.
 *
 * IDs never collide between the two sets: local presets keep their
 * existing string-slug id scheme (sanitize_key(basename($file,'.json'))),
 * remote presets get 'remote-' . $numeric_id.
 *
 * Because ids can't collide, they also can't detect a DUPLICATE — and some
 * local files are deliberate copies of a preset the remote also serves
 * (Progress Bar's Circle/Dot/Line), which would then be listed twice on a
 * healthy site. drop_shadowed_remote() removes that overlap by slug of the
 * name, and resolves it in the LOCAL file's favour; see its docblock for why
 * that inverts the usual remote-first rule.
 *
 * Once every local .json file is eventually deleted (planned), Local_Fallback
 * naturally returns [] for every type and this class's merge degrades to
 * remote-only automatically — no code change needed at that point.
 */
final class Cache {

	const TYPE_TRANSIENT_PREFIX = 'aaeaddon_preset_type_';
	const MANIFEST_OPTION       = 'aaeaddon_preset_manifest_cache';

	private Remote_Client $remote;
	private Local_Fallback $local;

	public function __construct( ?Remote_Client $remote = null, ?Local_Fallback $local = null ) {
		$this->remote = $remote ?? new Remote_Client();
		$this->local  = $local ?? new Local_Fallback();
	}

	private static function ttl(): int {
		/**
		 * Filters the remote preset cache TTL, in seconds.
		 *
		 * @param int $ttl Default 12 hours.
		 */
		return (int) apply_filters( 'aaeaddon_preset_cache_ttl', 12 * HOUR_IN_SECONDS );
	}

	/**
	 * Presets for one element type — remote (cached, manifest-diffed) merged
	 * with local (always read fresh, cheap glob). Never errors; an unknown
	 * type or a total remote outage still returns whatever local has (which
	 * may itself be []).
	 *
	 * `remote_failed` is true when the remote half could not be read at all
	 * (request failed AND no cached copy existed) — i.e. the returned list is
	 * INCOMPLETE, not authoritative. Consumers must not treat that case as
	 * "this type has no presets": doing so is what hid the editor's preset
	 * control for a whole session on one blip.
	 *
	 * @return array{presets: array<int, array>, remote_failed: bool}
	 */
	public function get_presets_for_type( string $type, string $category, bool $is_dev ): array {
		$local = $this->local->get_presets_for_type( $type );

		$remote = $is_dev
			? $this->fetch_remote_fresh( $type, $category )
			: $this->get_remote_cached_or_fetch( $type, $category );

		$entries = $remote['entries'];
		$failed  = $remote['failed'];

		// Pull in entries the server filed under a different element_type than
		// their model actually is — see REMOTE_TYPE_ALIASES.
		foreach ( self::REMOTE_TYPE_ALIASES[ $type ] ?? [] as $alias ) {
			$extra = $is_dev
				? $this->fetch_remote_fresh( $alias, $category )
				: $this->get_remote_cached_or_fetch( $alias, $category );

			$entries = array_merge( $entries, $this->only_models_of_type( $extra['entries'], $type ) );

			// If an alias fetch is what supplies this type's presets, a failure
			// there means the list is incomplete just as surely as a primary
			// failure does. Consumers key "this type has no presets" off this.
			$failed = $failed || $extra['failed'];
		}

		$remote_entries = $this->tag_remote( $this->resolve_asset_urls( $entries ) );

		return [
			'presets'       => array_merge( $this->drop_shadowed_remote( $remote_entries, $local ), $local ),
			'remote_failed' => $failed,
		];
	}

	/**
	 * Element types whose remote presets are filed on the server under a
	 * DIFFERENT element_type than the one their model actually is.
	 *
	 * The Stack Cards decks are the case this exists for. All ten are on the
	 * server with thumbnails, but filed as `e-aae-a-stack-card` (one CARD)
	 * while every one of their models is rooted at `e-aae-a-stack-cards` (the
	 * whole DECK, four cards plus the deck's own animation/overlap/ease
	 * settings). The picker asks the server for the type it has selected, gets
	 * nothing back for the deck, and falls through to the bundled local copies
	 * — which is why those presets appeared as `source: local` and carried no
	 * thumbnail, since Local_Fallback hardcodes an empty thumbnail_url.
	 *
	 * Fixing it properly means re-filing those rows on the preset server; this
	 * map is the client-side half so the presets work before that happens. It
	 * is deliberately explicit rather than "fetch every type and sort by
	 * model", which would mean pulling the whole catalogue on every request.
	 *
	 * @var array<string, array<int, string>>
	 */
	private const REMOTE_TYPE_ALIASES = [
		'e-aae-a-stack-cards' => [ 'e-aae-a-stack-card' ],
	];

	/**
	 * Keep only entries whose MODEL is rooted at `$type`.
	 *
	 * The model root is the authority on what a preset applies to — the
	 * server's own `element_type` field is what got this wrong. Entries with no
	 * model are dropped rather than guessed at: applying a preset whose target
	 * cannot be verified is worse than not offering it.
	 *
	 * @param array<int, array> $entries
	 * @return array<int, array>
	 */
	private function only_models_of_type( array $entries, string $type ): array {
		$out = [];
		foreach ( $entries as $entry ) {
			$model = $entry['model'] ?? null;
			if ( ! is_array( $model ) ) {
				continue;
			}
			$root = $model['widgetType'] ?? $model['elType'] ?? '';
			if ( $root === $type ) {
				$out[] = $entry;
			}
		}
		return $out;
	}

	/**
	 * Drop remote presets that a bundled local file already covers.
	 *
	 * Some local files are deliberate copies of presets that also live on the
	 * remote server (Progress Bar's Circle/Dot/Line). Without a dedup step a
	 * healthy site would list each of those designs twice.
	 *
	 * THE LOCAL COPY WINS, not the remote one — the opposite of the usual
	 * remote-first rule, and deliberate. A bundled file ships with the plugin
	 * and is version-matched to it: the Progress Bar presets reference
	 * `e-aae-a-progressbar-dot`/`-fill`/`-label`, part widgets whose twigs
	 * render progressbar.js's hook classes, so the preset carries no hook class
	 * in a `classes` prop and the panel has nothing to report as missing. The
	 * remote copies are still built from native div-blocks with those hooks in
	 * `classes`, where Elementor flags them AND offers a dismiss button that
	 * unapplies them. Preferring remote would mean the applied preset is the
	 * broken one on every online site — i.e. always.
	 *
	 * The cost: a genuinely improved remote preset is masked while a local file
	 * of the same name exists. That is the intended lifecycle — delete the
	 * local file (the stated end state for all of them) and the remote takes
	 * over with no code change.
	 *
	 * Identity is the slug of the NAME, the only field both halves share (the
	 * id schemes are disjoint by construction — see the class docblock — so ids
	 * can't detect a duplicate). A local entry is matched on its id too, since
	 * that id is its filename slug and a copy is normally named after the
	 * preset it mirrors.
	 *
	 * @param array<int, array> $remote
	 * @param array<int, array> $local
	 * @return array<int, array>
	 */
	private function drop_shadowed_remote( array $remote, array $local ): array {
		if ( empty( $remote ) || empty( $local ) ) {
			return $remote;
		}

		$taken = [];
		foreach ( $local as $entry ) {
			foreach ( [ $entry['id'] ?? '', $entry['name'] ?? '' ] as $candidate ) {
				$slug = self::slug( (string) $candidate );
				if ( '' !== $slug ) {
					$taken[ $slug ] = true;
				}
			}
		}

		if ( empty( $taken ) ) {
			return $remote;
		}

		return array_values(
			array_filter(
				$remote,
				static function ( array $entry ) use ( $taken ): bool {
					$slug = self::slug( (string) ( $entry['name'] ?? '' ) );

					return '' === $slug || ! isset( $taken[ $slug ] );
				}
			)
		);
	}

	/**
	 * Lowercase, every run of non-alphanumerics collapsed to one hyphen.
	 *
	 * Deliberately NOT sanitize_key(), which strips spaces rather than
	 * converting them — "Bold Overlay Zoom" would become "boldoverlayzoom" and
	 * never match a local `bold-overlay-zoom.json`.
	 */
	private static function slug( string $value ): string {
		$value = strtolower( trim( $value ) );

		return trim( (string) preg_replace( '/[^a-z0-9]+/', '-', $value ), '-' );
	}

	/**
	 * Remote preset models are authored/uploaded against the same
	 * `{{AAE_ASSET_URL}}` placeholder convention this plugin's own bundled
	 * local presets use (see Local_Fallback::parse_preset_file()) — the
	 * remote server has no knowledge of any one install's plugin URL, so it
	 * stores the literal token and expects each consuming site to resolve it
	 * to its own `AAEADDON_URL . 'inc/AtomicWidgets/'`.
	 *
	 * Local_Fallback resolves this at parse-time for local files; remote
	 * entries were never getting the same treatment, so any remote preset
	 * carrying an image-src/svg-src (or any other) URL built from this token
	 * shipped the literal placeholder string straight to the browser —
	 * rendering no icon/image, and failing Elementor's save-time URL
	 * validation with "Settings validation failed. <prop>: invalid_value" on
	 * publish. Resolved on every read (not baked into the transient) so it
	 * always reflects the CURRENT site's URL, exactly like Local_Fallback.
	 *
	 * @param array<int, array> $entries
	 * @return array<int, array>
	 */
	private function resolve_asset_urls( array $entries ): array {
		if ( empty( $entries ) || ! defined( 'AAEADDON_URL' ) ) {
			return $entries;
		}

		$json = wp_json_encode( $entries );
		if ( ! is_string( $json ) ) {
			return $entries;
		}

		$json = str_replace( '{{AAE_ASSET_URL}}', AAEADDON_URL . 'inc/AtomicWidgets/', $json );

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : $entries;
	}

	private function tag_remote( array $entries ): array {
		return array_map(
			static function ( array $entry ): array {
				$entry['id']     = 'remote-' . ( $entry['id'] ?? '' );
				$entry['source'] = 'remote';

				return $entry;
			},
			$entries
		);
	}

	/**
	 * @return array{entries: array<int, array>, failed: bool}
	 */
	private function get_remote_cached_or_fetch( string $type, string $category ): array {
		$transient_key = self::TYPE_TRANSIENT_PREFIX . $type;
		$cached        = get_transient( $transient_key );

		if ( false !== $cached && is_array( $cached ) ) {
			$this->maybe_refresh_via_manifest( $type, $category, $cached, $transient_key );

			// A cached copy always counts as a successful read, even if the
			// manifest refresh above hit the network and failed — the list we
			// return is still a complete answer for this type.
			$fresh = get_transient( $transient_key );

			return [
				'entries' => ( false !== $fresh && is_array( $fresh ) ) ? $fresh : $cached,
				'failed'  => false,
			];
		}

		return $this->fetch_remote_fresh( $type, $category, $transient_key );
	}

	/**
	 * Fetches the full bulk list and caches it (even if empty, so a type
	 * with legitimately nothing on the server doesn't get re-requested on
	 * every single page load) — but ONLY when the server actually answered.
	 * A FAILED request is never cached: writing [] into a 12-hour transient
	 * over one network blip would blank that type's presets until the TTL
	 * expired. On dev/local environments, still returns the fresh result but
	 * never touches the transient.
	 *
	 * @return array{entries: array<int, array>, failed: bool}
	 */
	private function fetch_remote_fresh( string $type, string $category, ?string $cache_key = null ): array {
		$entries = $this->remote->fetch_presets_for_type( $type, $category );

		if ( null === $entries ) {
			return [
				'entries' => [],
				'failed'  => true,
			];
		}

		if ( null !== $cache_key ) {
			set_transient( $cache_key, $entries, self::ttl() );
			$this->update_manifest_option( $type, $entries );
		}

		return [
			'entries' => $entries,
			'failed'  => false,
		];
	}

	/**
	 * Manifest-diff optimization: hit the cheap /manifest endpoint (no
	 * bodies) and only re-fetch full bodies for entries whose hash actually
	 * changed since the last cache write, or whose id is new/removed.
	 * Avoids re-downloading unchanged preset JSON on every cache-refresh
	 * cycle. If the manifest call itself fails, the existing (possibly
	 * stale) cached array is left untouched rather than cleared.
	 */
	private function maybe_refresh_via_manifest( string $type, string $category, array $cached, string $transient_key ): void {
		$manifest = $this->remote->fetch_manifest( $type, $category );

		if ( empty( $manifest ) && ! empty( $cached ) ) {
			// Could be a genuine "nothing on server" or a transient network
			// hiccup — either way, don't destroy a working cache over an
			// ambiguous empty manifest response; next natural TTL expiry
			// will re-attempt a full fetch.
			return;
		}

		$manifest_hashes = [];

		foreach ( $manifest as $entry ) {
			if ( isset( $entry['id'], $entry['hash'] ) ) {
				$manifest_hashes[ (int) $entry['id'] ] = (string) $entry['hash'];
			}
		}

		$stored_option = get_option( self::MANIFEST_OPTION, [] );
		$stored_hashes = $stored_option[ $type ] ?? [];

		$changed_ids = [];
		foreach ( $manifest_hashes as $id => $hash ) {
			if ( ( $stored_hashes[ $id ] ?? null ) !== $hash ) {
				$changed_ids[] = $id;
			}
		}

		$removed_ids = array_diff( array_keys( $stored_hashes ), array_keys( $manifest_hashes ) );

		if ( empty( $changed_ids ) && empty( $removed_ids ) ) {
			// Nothing changed — just extend the existing cache's life.
			set_transient( $transient_key, $cached, self::ttl() );
			return;
		}

		// Re-index cached entries by their numeric remote id for easy patching.
		$by_id = [];
		foreach ( $cached as $entry ) {
			$raw_id = isset( $entry['id'] ) ? (string) $entry['id'] : '';
			$numeric_id = (int) str_replace( 'remote-', '', $raw_id );
			$by_id[ $numeric_id ] = $entry;
		}

		foreach ( $removed_ids as $removed_id ) {
			unset( $by_id[ (int) $removed_id ] );
		}

		foreach ( $changed_ids as $changed_id ) {
			$fresh = $this->remote->fetch_single( (int) $changed_id );

			if ( null !== $fresh ) {
				$by_id[ (int) $changed_id ] = $fresh;
			}
		}

		$refreshed = array_values( $by_id );

		set_transient( $transient_key, $refreshed, self::ttl() );
		$this->update_manifest_option( $type, $refreshed );
	}

	private function update_manifest_option( string $type, array $entries ): void {
		$option = get_option( self::MANIFEST_OPTION, [] );

		$hashes = [];
		foreach ( $entries as $entry ) {
			$raw_id     = isset( $entry['id'] ) ? (string) $entry['id'] : '';
			$numeric_id = (int) str_replace( 'remote-', '', $raw_id );

			if ( $numeric_id > 0 && isset( $entry['hash'] ) ) {
				$hashes[ $numeric_id ] = (string) $entry['hash'];
			}
		}

		$option[ $type ] = $hashes;

		update_option( self::MANIFEST_OPTION, $option, false );
	}
}
