<?php
namespace Wealcoder\AnimationAddons\Atomic;

use Wealcoder\AnimationAddons\AtomicWidgets\Atomic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Bootstrap {

	const MIN_ELEMENTOR_VERSION = '4.0.0';


	public static function get_label( $text ) {
		return $text;
	}


	public static function init(): void {
		if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			return;
		}

		if ( version_compare( ELEMENTOR_VERSION, self::MIN_ELEMENTOR_VERSION, '<' ) ) {
			return;
		}

		// This can run before animation-addons-for-elementor.php's own
		// require_once for it (class-plugin.php's require, further up the
		// call stack, executes Bootstrap::init() synchronously), so load it
		// defensively here. require_once is a no-op on the later, normal load.
		if ( ! class_exists( Atomic::class ) ) {
			require_once AAEADDON_PATH . 'inc/AtomicWidgets/class-atomic.php';
		}

		$extensions = Atomic::instance();

		// Schema + Controls only. The editor UI for these twelve extensions stays
		// in the free plugin — the panel sections must keep appearing and saving
		// on a free site, and the Schema must keep existing or Elementor erases
		// every aae_* prop from _elementor_data on the next save.
		//
		// Their Render classes and effect bundles live in the Pro plugin
		// (inc/AtomicV4/Extensions/). Nothing here renders them; a site without a
		// licensed Pro shows the settings and no animation, which is the point.
		// See animation-addons-for-elementor-pro/docs/atomic-v4/extension-frontend-migration.md.

		// Regular (preset-based) animation — applied to every atomic widget.
		// Frontend reads window.AAE_INTERACTIONS_ANIM[<id>].
		if ( $extensions->is_extension_active( 'regular-animation' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\RegularAnimation\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\RegularAnimation\Controls() )->register();
		}

		// Parallax (ScrollSmoother) — applied to every atomic widget.
		// Frontend reads window.AAE_INTERACTIONS_PLX[<id>].
		if ( $extensions->is_extension_active( 'parallax' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\Parallax\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\Parallax\Controls() )->register();
		}

		// Text animation — char/word/reveal/etc. for heading-class widgets.
		if ( $extensions->is_extension_active( 'text-animation' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\TextAnimation\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\TextAnimation\Controls() )->register();
		}

		// Image animation — reveal/scale/stretch for e-image / e-svg.
		// Frontend reads window.AAE_INTERACTIONS_IMG[<id>].
		if ( $extensions->is_extension_active( 'image-animation' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\ImageAnimation\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ImageAnimation\Controls() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ImageAnimation\Render() )->register();
		}

		// Image hover — cursor-following floating image overlay on any
		// atomic widget. Frontend reads window.AAE_INTERACTIONS_IH[<id>].
		if ( $extensions->is_extension_active( 'image-hover' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\ImageHover\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ImageHover\Controls() )->register();
		}

		// Sticky — pin elements
		if ( $extensions->is_extension_active( 'sticky' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\Sticky\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\Sticky\Controls() )->register();
		}

		// horizontal scroll animation
		if ( $extensions->is_extension_active( 'horizontal-scroll-anim' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\HorizontalScrollAnim\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\HorizontalScrollAnim\Controls() )->register();
		}

		// Cursor hover effect — cursor-following floating element on any
		if ( $extensions->is_extension_active( 'cursor-hover-effect' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\CursorHoverEffect\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\CursorHoverEffect\Controls() )->register();
		}

		// Mouse move effect — element moves based on mouse position.
		if ( $extensions->is_extension_active( 'mouse-move-effect' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\MouseMoveEffect\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\MouseMoveEffect\Controls() )->register();
		}

		// Advance Tooltip
		if ( $extensions->is_extension_active( 'advance-tooltip' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\AdvanceTooltip\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\AdvanceTooltip\Controls() )->register();
		}

		// Tilt
		if ( $extensions->is_extension_active( 'tilt' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\Tilt\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\Tilt\Controls() )->register();
		}

		// scrollto
		if ( $extensions->is_extension_active( 'scroll-to' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\ScrollTo\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ScrollTo\Controls() )->register();
		}

		// Image Overlay — static color/gradient tint on e-image / e-svg.
		// Fully free (Schema+Controls+Render), unlike the twelve GSAP-driven
		// shared extensions above: it needs no JS animation runtime, just a
		// plain background + mix-blend-mode application. See Render.php.
		if ( $extensions->is_extension_active( 'image-overlay' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\ImageOverlay\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ImageOverlay\Controls() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\ImageOverlay\Render() )->register();
		}

		// Mask — clips an element to a shape. Registered as real atomic STYLE
		// props (`mask-image` & friends on the styles schema), NOT settings
		// props, so responsive values, :hover variants and global classes come
		// from Elementor's own styles engine and the CSS compiles into the
		// element's stylesheet — no runtime JS. v3's mask is widget-only, so
		// containers gain something they never had.
		if ( $extensions->is_extension_active( 'mask' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\Mask\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\Mask\Transformers() )->register();
		}

		// Background Video — a video layer behind e-flexbox / e-div-block /
		// e-grid. Wholly free (Schema + Controls + Render + runtime): it adds
		// what v4's atomic Background control is missing rather than an
		// animation, and it needs no GSAP, so there is nothing here for the Pro
		// split to own. Frontend reads window.AAE_INTERACTIONS_BGV[<id>].
		if ( $extensions->is_extension_active( 'background-video' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\BackgroundVideo\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\BackgroundVideo\Controls() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\BackgroundVideo\Render() )->register();
		}

		// Custom CSS — NOT part of the move to Pro, so it keeps its Render here.
		// Presets are the reason: an "animated" preset (keyframes, ::before
		// layers, descendant :hover — anything atomic per-element styles cannot
		// express) bakes its CSS into THIS extension's props, so a preset that
		// uses them renders as a static element, with no error, wherever the
		// extension is missing. That is true of remote presets as much as
		// bundled ones. (It used to cite two bundled free presets by name;
		// those files are gone — see the Presets note below — but the
		// dependency is a property of the preset format, not of those files.)
		if ( $extensions->is_extension_active( 'custom-css' ) ) {
			( new \Wealcoder\AnimationAddons\Atomic\CustomCss\Schema() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\CustomCss\Controls() )->register();
			( new \Wealcoder\AnimationAddons\Atomic\CustomCss\Render() )->register();
		}

		// Presets — "Apply Preset" picker section for NATIVE atomic widgets
		// (e-heading, e-button, …). AAE's own widgets add the section
		// themselves in define_atomic_controls(); this only covers types whose
		// classes we do not own.
		//
		// CURRENTLY A NO-OP, deliberately: injection is driven by
		// Controls::ALLOWED_NATIVE_TYPES, which is empty, so no native widget
		// offers the picker. It is registered anyway because the whitelist is
		// the intended on-switch — put a type in it and the section returns.
		// The section does NOT appear just because presets exist for a type;
		// that was the old behaviour and it surfaced "Presets" on widgets
		// nobody had opted in (e-paragraph, e-image), which is why the
		// whitelist replaced it.
		( new \Wealcoder\AnimationAddons\Atomic\Presets\Controls() )->register();

		// Nested Slider. (No Controls class — the slider's panel section is built
		// directly in Aaeaddon_A_Slider::define_atomic_controls(), so there's nothing
		// to inject via the controls filter.)
		( new \Wealcoder\AnimationAddons\Atomic\NestedSlider\Schema() )->register();
		( new \Wealcoder\AnimationAddons\Atomic\NestedSlider\Render() )->register();

		// Loop Grid Slider — reuses the Nested Slider schema (NS_*) and the shared
		// 'ns' InteractionsMap namespace + runtime, so no separate Schema is needed.
		// This Render only publishes the config for e-aae-a-loop-grid-slider and
		// enqueues the shared slider runtime plus the load-more bridge.
		( new \Wealcoder\AnimationAddons\Atomic\LoopGridSlider\Render() )->register();

		// Style Manager — registers AAE utility classes (aae-flex, aae-a-p0,
		// aae-a-svg, …) via the atomic styles pipeline.
		( new \Wealcoder\AnimationAddons\Atomic\StyleManager\Manager() )->register();

		// Preset interaction styles — keyed CSS map, printed inline on demand
		// for the presets actually used on the page (see Preset_Styles).
		( new \Wealcoder\AnimationAddons\Atomic\StyleManager\Preset_Styles() )->register();

		( new Assets() )->register();

		// Elementor's own atomic handler bundles (YouTube, Tabs, action links)
		// are webpack chunks that never execute on a V4-only page, because the
		// runtime they need only ships with a CLASSIC element. One added
		// dependency; see the class docblock for the measurement.
		( new \Wealcoder\AnimationAddons\Atomic\Compat\Elementor_Chunk_Runtime() )->register();

		// Editor schema trim — strips each extension's props from the EDITOR
		// copy of every atomic type the extension does not apply to. The
		// props-schema filter has no element argument, so every module above
		// adds its props to every type; the server keeps that (it is what
		// protects saved data on save), the client does not need it. See the
		// class docblock for the rule that keeps this safe.
		//
		// is_admin() gates the CONSTRUCTION, not the behaviour: its two hooks
		// are elementor/editor/localize_settings and
		// elementor/ajax/register_actions, and the editor (post.php?action=
		// elementor) and elementor_ajax both answer is_admin(). Neither can
		// fire on a visitor's request, so off-admin the class was 16 KB parsed
		// for nothing. The preview iframe is deliberately not a concern --
		// localize_settings is not fired there, and the SERVER schema it must
		// never trim is registered by the modules above, not here.
		if ( is_admin() ) {
			( new \Wealcoder\AnimationAddons\Atomic\Editor\Schema_Trim() )->register();
		}

		// Remote preset system — the same-origin proxy route the editor's JS
		// fetches (merges remote + local presets; see Atomic\Presets\Cache).
		// The "Presets" panel section itself is registered once, above.
		( new \Wealcoder\AnimationAddons\Atomic\Presets\Rest() )->register();

		// The install door for a preset that needs a post type, an ACF field
		// group or a plugin before its design can do anything. Free owns the
		// door — nonce, capability, and the decision about what a given preset
		// requires — and Pro owns what is behind it, so a site without Pro gets
		// an honest "nothing can install this" instead of a 400 from an action
		// nobody registered. See Presets\Requires.
		//
		// wp_ajax_ is the only hook it registers, so it is admin by definition
		// -- the door is opened from the editor panel, which posts to
		// admin-ajax. Nothing here is reachable from a visitor's request.
		if ( is_admin() ) {
			( new \Wealcoder\AnimationAddons\Atomic\Presets\Requires() )->register();
		}
	}

	/**
	 * Every element type the shared extensions (Regular Animation, Parallax,
	 * Tilt, Scroll To, Mouse Move, Cursor Hover, Advance Tooltip, Image Hover,
	 * Custom CSS) offer their panel section on.
	 *
	 * PARENT WIDGETS ONLY, deliberately. Composite widgets register their
	 * structural children as separate element types (`e-aae-a-accordion-item`,
	 * `e-aae-a-form-input`, `e-aae-a-timeline-year`, …) — 100+ of them, all
	 * flagged `is_internal => true` in `AtomicWidgets\Atomic`'s registry and
	 * mapped to their parent in `WIDGET_PARENT_MAP`. Listing those here would
	 * put nine extension sections on every internal part a user can select,
	 * for no gain: animating the part is what animating the parent already
	 * does, and the panel noise is proportional to the part count.
	 *
	 * TWO sets of internal children are exempt from that rule.
	 *
	 * `e-aae-a-icon-list-item` is the first. It predates the rule and saved
	 * pages already carry `aae_*` props on it — removing it would strip them
	 * on the next save (Props_Parser::validate() erases any prop the schema
	 * does not declare). Do not "tidy" it out.
	 *
	 * The Nested Slider's parts are the second, and unlike the icon-list item
	 * they are here on purpose. A slide, the track, the arrows, the dots and
	 * the progress bar are generated by the slider; animating the slider root
	 * does NOT reach them, so the "animating the part is what animating the
	 * parent already does" argument that keeps every other internal child out
	 * does not hold here. They are the parts a user actually selects in the
	 * structure panel, and every shared extension has to be reachable there.
	 * The Loop Grid Slider reuses the same part types, so one entry covers both.
	 *
	 * Pro-owned types (`e-aae-a-offcanvas`, `e-aae-a-btn-pro`, `e-aae-a-lottie`, …)
	 * belong here too — atomic element types can only be REGISTERED from the
	 * free plugin, and this list is matched by type string, so it is the same
	 * seam either way.
	 *
	 * Adding a type here is not enough on its own: the matching editor-bridge
	 * list in `src/modules/atomic/editor-bridge/features.js` decides which
	 * types mirror LIVE into the canvas, and a type present here but missing
	 * there reads as "works on the frontend, never updates in the editor".
	 *
	 * @return string[]
	 */
	public static function target_element_types(): array {
		return [
			// Elementor core atomic elements.
			'e-heading',
			'e-paragraph',
			'e-button',
			'e-image',
			'e-svg',
			'e-flexbox',
			'e-div-block',
			'e-grid',

			// Content / dynamic.
			'e-aae-a-post-title',
			'e-aae-a-post-image',
			'e-aae-a-post-content',
			'e-aae-a-posts',
			'e-aae-a-post-pagination',
			'e-aae-a-loop-grid',
			'e-aae-a-loop-grid-slider',
			'e-aae-a-search-form',
			'e-aae-a-search-query',
			'e-aae-a-toc',
			'e-aae-a-site-logo',

			// Navigation.
			'e-aae-a-nav',
			'e-aae-a-menu',
			'e-aae-a-offcanvas',

			// Interactive / composite.
			'e-aae-a-accordion',
			'e-aae-a-toggle-switcher',
			'e-aae-a-slider',
			'e-aae-a-stack-cards',
			'e-aae-a-timeline',
			'e-aae-a-flip-box',
			'e-aae-a-image-compare',
			'e-aae-a-image-hotspot',
			'e-aae-a-form',

			// Media.
			'e-aae-a-video',
			'e-aae-a-video-mask',
			'e-aae-a-lottie',
			'e-aae-a-draw-svg',

			// Basic.
			'e-aae-a-advanced-heading',
			'e-aae-a-btn',
			'e-aae-a-btn-pro',
			'e-aae-a-counter',
			'e-aae-a-countdown',
			'e-aae-a-progressbar',
			'e-aae-a-social-share',
			'e-aae-a-icon-list',
			'e-aae-a-curved-text',

			// Nested Slider / Loop Grid Slider parts — internal children the
			// slider generates, which animating the slider root cannot reach.
			// See the docblock.
			'e-aae-a-slider-track',
			'e-aae-a-slide',
			'e-aae-a-slider-nav-prev',
			'e-aae-a-slider-nav-next',
			'e-aae-a-slider-pagination',
			'e-aae-a-slider-dot',
			'e-aae-a-slider-indicators',
			'e-aae-a-slider-progress',
			'e-aae-a-slider-progress-fill',
			'e-aae-a-slider-percentage',
			'e-aae-a-slider-counter',
			'e-aae-a-slider-current',
			'e-aae-a-slider-total',
			'e-aae-a-slider-divider',

			// Internal child — kept for back-compat only, see the docblock.
			'e-aae-a-icon-list-item',
		];
	}
}
